﻿using Microsoft.AspNetCore.Identity;

namespace Register_LogIn_LogOut_Identity.Models
{
    public class ApplicationRole : IdentityRole
    {
        public string Description { get; set; }
    }
}
