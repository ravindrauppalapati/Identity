using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Register_LogIn_LogOut_Identity.Data;
using Register_LogIn_LogOut_Identity.Models;

namespace Register_LogIn_LogOut_Identity
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            var connectionString = builder.Configuration.GetConnectionString("DbConnection") ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
            builder.Services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(connectionString));
            builder.Services.AddDatabaseDeveloperPageExceptionFilter();

            builder.Services.AddIdentity<ApplicationUser,ApplicationRole>(opts=>
            { 
                 //custom password policy
                opts.Password.RequireDigit=true;
                opts.Password.RequireLowercase=true;
                opts.Password.RequireUppercase=true;
                opts.Password.RequiredLength=8;
                opts.Password.RequireNonAlphanumeric=true;
                opts.Password.RequiredUniqueChars = 4;
            })
                .AddEntityFrameworkStores<ApplicationDbContext>();
            builder.Services.AddControllersWithViews();
          
            builder.Services.AddAuthorization(opts => {
                opts.AddPolicy("DeleteRolePolicy", p => p.RequireClaim("Delete Role")
                                                         .RequireClaim("Edit Role"));
                                                    
            });

            builder.Services.AddAuthorization(opts => {
                opts.AddPolicy("DeleteRolePolicy", p => p.RequireClaim("Delete Role") ) ; 
                opts.AddPolicy("EditRolePolicy", p => p.RequireClaim("Edit Role") ) ;

            });
            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (app.Environment.IsDevelopment())
            {
                app.UseMigrationsEndPoint();
            }
            else
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Home}/{action=Index}/{id?}");
            //app.MapRazorPages();

            app.Run();
        }
    }
}
