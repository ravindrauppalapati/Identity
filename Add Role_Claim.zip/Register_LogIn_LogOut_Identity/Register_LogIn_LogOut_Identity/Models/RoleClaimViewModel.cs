﻿using System.ComponentModel.DataAnnotations;

namespace Register_LogIn_LogOut_Identity.Models
{
    public class RoleClaimViewModel
    {
        public RoleClaimViewModel()
        {
            claims = new List<RoleClaim>();
        }
        [Key]
        public string RoleId { get; set; }

        public List<RoleClaim> claims { get;set; }
    }
}
