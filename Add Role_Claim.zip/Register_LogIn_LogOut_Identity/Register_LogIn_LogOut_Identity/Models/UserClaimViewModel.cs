﻿using System.ComponentModel.DataAnnotations;

namespace Register_LogIn_LogOut_Identity.Models
{
    public class UserClaimViewModel
    {
        public UserClaimViewModel()
        {
            Claims = new List<UserClaim>();
        }

        [Key]
        public string UserId { get; set; }
        public List<UserClaim> Claims { get; set; }

    }
}
