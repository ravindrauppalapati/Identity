﻿using System.ComponentModel.DataAnnotations;

namespace Register_LogIn_LogOut_Identity.Models
{
    public class UserClaim
    {
        [Key]
        public string ClaimType { get; set; }
        public bool IsSeleted { get; set; }
    }
}
