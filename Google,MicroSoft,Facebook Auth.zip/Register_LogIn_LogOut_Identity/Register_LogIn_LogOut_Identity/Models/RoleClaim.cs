﻿using System.ComponentModel.DataAnnotations;

namespace Register_LogIn_LogOut_Identity.Models
{
    public class RoleClaim
    {
        [Key]
        public string ClaimType { get; set; }
        public bool IsSelected { get; set; }
    }
}
